Please be specific when describing the issue. Also, these details will help:

- VersionPress version: 
- WordPress version:
- OS, webserver, PHP:
- Git version:

You can get more details from your system info page: <http://docs.versionpress.net/en/troubleshooting/system-info-page>