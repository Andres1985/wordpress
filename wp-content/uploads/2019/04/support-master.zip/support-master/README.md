# VersionPress Support

- For a quick chat, find us [**on Gitter**](https://gitter.im/versionpress/versionpress).
- To provide details, **open an issue in this repo**:
    1. **Search** the existing issues, for example,  [this searches for Apache issues](https://github.com/versionpress/support/issues?utf8=%E2%9C%93&q=Apache+is%3Aissue).
    2. [Create new issue](https://github.com/versionpress/support/issues/new).

:warning: This repo and all you share here is **public**. Make sure to remove any private information.

Note that this is a **community support**, provided on a best effort basis.
